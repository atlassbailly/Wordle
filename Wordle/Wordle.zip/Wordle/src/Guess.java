public class Guess {

    private char[] guess;
    private int index;

    public int getIndex() { return index; }

    public char[] getGuess() { return guess; }

    public Guess(){
        guess = new char[5];
        for(int i = 0; i < 5; i++){
            guess[i] = '0';
        }
        index = -1;
    }

    public void add(char c){
        if(index < 4) {
            index++;
            guess[index] = c;
        }
    }

    public void backspace() {
        if (index > -1){
            guess[index] = '0';
            index--;
        }
    }
}