import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import static java.nio.file.Files.readAllBytes;

public class Dictionary {

    public Dictionary() {

    }

    public static boolean isInDictionary(String word, Scanner dictionary) {

        List<String> dictionaryList = new ArrayList<String>();
        for (int i = 0; dictionary.hasNextLine() != false; i++) {
            dictionaryList.add(dictionary.nextLine());
            if (dictionaryList.get(i).equalsIgnoreCase(word)) {
                return true;
            }
        }

        return false;

    }
}